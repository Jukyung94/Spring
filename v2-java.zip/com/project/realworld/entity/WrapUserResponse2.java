package com.project.realworld.entity;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class WrapUserResponse2 {
    private UserResponse2 user;
}
